def key_get(eventkey):
    if eventkey == 32:
        return ' '
    elif eventkey == 39:
        return '"'
    elif eventkey == 44:
        return '<'
    elif eventkey == 45:
        return '_'
    elif eventkey == 46:
        return '>'
    elif eventkey == 47:
        return '?'
    elif eventkey == 48:
        return '0'
    elif eventkey == 49:
        return '1'
    elif eventkey == 50:
        return '2'
    elif eventkey == 51:
        return '3'
    elif eventkey == 52:
        return '4'
    elif eventkey == 53:
        return '5'
    elif eventkey == 54:
        return '6'
    elif eventkey == 55:
        return '7'
    elif eventkey == 56:
        return '8'
    elif eventkey == 57:
        return '9'
    elif eventkey == 59:
        return ':'
    elif eventkey == 61:
        return '='
    elif eventkey == 91:
        return '{'
    elif eventkey == 92:
        return '\\'
    elif eventkey == 93:
        return '}'
    elif eventkey == 96:
        return '~'
    elif eventkey == 97:
        return 'a'
    elif eventkey == 98:
        return 'b'
    elif eventkey == 99:
        return 'c'
    elif eventkey == 100:
        return 'd'
    elif eventkey == 101:
        return 'e'
    elif eventkey == 102:
        return 'f'
    elif eventkey == 103:
        return 'g'
    elif eventkey == 104:
        return 'h'
    elif eventkey == 105:
        return 'i'
    elif eventkey == 106:
        return 'j'
    elif eventkey == 107:
        return 'k'
    elif eventkey == 108:
        return 'l'
    elif eventkey == 109:
        return 'm'
    elif eventkey == 110:
        return 'n'
    elif eventkey == 111:
        return 'o'
    elif eventkey == 112:
        return 'p'
    elif eventkey == 113:
        return 'q'
    elif eventkey == 114:
        return 'r'
    elif eventkey == 115:
        return 's'
    elif eventkey == 116:
        return 't'
    elif eventkey == 117:
        return 'u'
    elif eventkey == 118:
        return 'v'
    elif eventkey == 119:
        return 'w'
    elif eventkey == 120:
        return 'x'
    elif eventkey == 121:
        return 'y'
    elif eventkey == 122:
        return 'z'
    elif eventkey == 256:
        return '0'
    elif eventkey == 257:
        return '1'
    elif eventkey == 258:
        return '2'
    elif eventkey == 259:
        return '3'
    elif eventkey == 260:
        return '4'
    elif eventkey == 261:
        return '5'
    elif eventkey == 262:
        return '6'
    elif eventkey == 263:
        return '7'
    elif eventkey == 264:
        return '8'
    elif eventkey == 265:
        return '9'
    elif eventkey == 267:
        return '/'
    elif eventkey == 268:
        return '*'
    elif eventkey == 269:
        return '-'
    elif eventkey == 270:
        return '+'
    else:
        return ''

